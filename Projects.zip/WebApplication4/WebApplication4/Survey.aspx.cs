﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.IO;
using System.Data;
using Microsoft.VisualBasic.FileIO;
using LumenWorks.Framework.IO.Csv;
using System.Diagnostics;

namespace WebApplication4
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
           
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            string newFileName = "C:\\Users\\vgz8b\\Desktop\\input.csv";

            string clientDetails = TextBox1.Text + "," + TextBox2.Text + "," + TextBox3.Text + "," + TextBox4.Text + "," + TextBox5.Text + "," + TextBox6.Text + "," + TextBox7.Text + "," + TextBox8.Text + "," + TextBox9.Text + "," + TextBox10.Text + "," + TextBox11.Text + "," + TextBox12.Text + "," + TextBox13.Text + "," + TextBox14.Text + "," + TextBox15.Text + "," + TextBox16.Text + "," + TextBox17.Text + "," + TextBox18.Text + "," + TextBox19.Text + "," + TextBox20.Text + "," + TextBox21.Text + "," + TextBox22.Text + "," + TextBox23.Text + "," + TextBox24.Text +","+""+ Environment.NewLine ;


            if (!File.Exists(newFileName))
            {
                string clientHeader = "Client Name(ie. Billto_desc)" + "," + "Mid_id,billing number(ie billto_id)" + "," + "business unit id" + Environment.NewLine;

                File.WriteAllText(newFileName, clientHeader);
            }

            File.AppendAllText(newFileName, clientDetails);

            Process p = new Process();
            // Redirect the output stream of the child process.

            //p.StartInfo.Verb = "runas";
            //p.StartInfo.WindowStyle = ProcessWindowStyle.Hidden;
            p.StartInfo.UseShellExecute = false;
            p.StartInfo.RedirectStandardOutput = true;
            p.StartInfo.Arguments = "/user:Administrator cmd /K ";
            p.StartInfo.FileName = @"C:\Users\vgz8b\Documents\Visual Studio 2010\Projects\ConsoleApplication4\ConsoleApplication4\bin\Debug\ConsoleApplication4.exe";
            p.Start();
            // Do not wait for the child process to exit before
            // reading to the end of its redirected stream.
            // p.WaitForExit();
            // Read the output stream first and then wait.

            p.WaitForExit();

            using (CsvReader csv =
           new CsvReader(new StreamReader("C:\\Users\\vgz8b\\Desktop\\input_score_idents.csv"), true))
            {
                int fieldCount = csv.FieldCount;

                string[] headers = csv.GetFieldHeaders();
                while (csv.ReadNextRecord())
                {
                    for (int i = 0; i < fieldCount; i++)
                    {
                        if (csv[0].ToString() == TextBox1.Text)
                        {
                            predict.InnerHtml = "<font color=green size=18><br/><center><h2>Your Estimated Bill is $" + Math.Round(Convert.ToDecimal(csv[fieldCount - 1]),2)+"</h2></center></font><br/><br/>";
                        }
                    }


                }
            } 



           
        }
        
    }
}