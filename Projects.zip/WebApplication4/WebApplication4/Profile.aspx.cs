﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using LumenWorks.Framework.IO.Csv;
using System.IO;

namespace WebApplication4
{
    public partial class WebForm2 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            using (CsvReader csv =
           new CsvReader(new StreamReader("C:\\Users\\vgz8b\\Desktop\\input.csv"), true))
            {
                int fieldCount = csv.FieldCount;

                string[] headers = csv.GetFieldHeaders();
                while (csv.ReadNextRecord())
                {
                    for (int i = 0; i < fieldCount; i++)
                    {
                        if (csv[0].ToString() == TextBox1.Text)
                        {
                            res.InnerHtml = "<font color=green>Number of Refrigerators : " + csv[5] + "</font>"+"&nbsp;&nbsp;&nbsp; <a href=#>Visual Statistics</a>"+"<br/>";
                            res.InnerHtml += "<font color=green>Use a microwave Oven to do any cooking : " + csv[2] + "</font>" + "&nbsp;&nbsp;&nbsp; <a href=#>Visual Statistics</a>" + "<br/>";
                            res.InnerHtml += "<font color=green>How many loads of laundry are washed in a week : " + csv[6] + "</font>" + "&nbsp;&nbsp;&nbsp; <a href=#>Visual Statistics</a>" + "<br/>";
                            res.InnerHtml += "<font color=green>Number of Fans : " + csv[9] + "</font>" + "&nbsp;&nbsp;&nbsp; <a href=#>Visual Statistics</a>" + "<br/>";

                        }
                    }


                }
            } 

        }
    }
}